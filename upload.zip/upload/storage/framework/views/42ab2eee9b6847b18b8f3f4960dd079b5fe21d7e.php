<?php $__env->startSection('judul'); ?>
Detil Tugas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<h1><?php echo e($data->id); ?></h1>
<table class="table table-hover">
	<thead>
		<tr>
			<th><center>Judul</center></th>
			<th><center>Deskripsi</center></th>
			<th><center>Dibuat Pada</center></th>
		</tr>
	</thead>
	<tbody>		
		<tr>
			<td><center><?php echo e($data->judul); ?></center></td>
			<td><center><?php echo e($data->deskripsi); ?></center></td>
			<td><center><?php echo e($data->created_at); ?></center></td>
		</tr>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>