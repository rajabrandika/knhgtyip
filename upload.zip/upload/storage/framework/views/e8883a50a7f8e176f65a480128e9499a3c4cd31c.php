<?php $__env->startSection('judul'); ?>
Daftar Tugas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<table class="table table-striped b-t b-light">
	<thead>
		<tr>
			<th><center>Judul</center></th>
			<th><center>Detil</center></th>
			<th><center>Edit</center></th>
			<th><center>Hapus</center></th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><center><?php echo e($a->judul); ?></center></td>
			<td><center>
				<a href="<?php echo e(url('tugas/'.$a->id)); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i></a>
			</center></td>
			<td><center>
				<a href="<?php echo e(url('tugas/'.$a->id.'/edit')); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-edit"></i></a>
			</center></td>
			<td><center>
				<form action="<?php echo e(url('tugas/'.$a->id)); ?>" method="post">
					<input type="hidden" name="_method" value="DELETE">
					<?php echo e(csrf_field()); ?>

					<input type="submit" class="btn btn-danger" value="Hapus">
				</form>
			</center></td>
		</tr>
		<!-- <a href="<?php echo e(url('tugas/daftartugas')); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i></a> -->
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>