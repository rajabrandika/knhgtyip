<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('judul'); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/bootstrap/css/bootstrap.min.css')); ?>">
</head>
<a href="<?php echo e(url('/tugas/tts')); ?>">TESTING</a>
<a href="<?php echo e(url('/tugas/create')); ?>" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Tambah</a>
<body>
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<a href="<?php echo e(url('/tugas/create')); ?>" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Tambah</a>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<?php echo $__env->yieldContent('konten'); ?>
		</div>
	</div>
</body>
</html>