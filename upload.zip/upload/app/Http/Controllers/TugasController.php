<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Tugas;

class TugasController extends Controller
{
    public function index(){
    	// SELECT * FROM tugas
    	$data = Tugas::all();
    	return view('tugas.daftartugas')->with('data', $data);
    }
    public function create(){
    	return view('tugas.buattugas');
    }
    public function tts(){
        return view('tugas.buattugas');
    }
    public function store(Request $request){
    	Tugas::create($request->all());
    	return redirect('tugas');
    }
    public function show($id){
    	// SELECT * FROM tugas WHERE id='$id'
    	$data = Tugas::find($id);
    	return view('tugas.detiltugas')->with('data', $data);
    }
    public function edit($id){
    	// SELECT * FROM tugas WHERE id='$id'
    	$data = Tugas::find($id);
    	return view('tugas.edittugas')->with('data', $data);
    }
    public function update(Request $request, $id){
    	//UPDATE tugas SET ..=.. WHERE id=$id
    	Tugas::find($id)->update($request->all());
    	return redirect('tugas');
    }
    public function destroy($id){
    	Tugas::find($id)->delete();
    	return redirect('tugas');
    }
}
?>
