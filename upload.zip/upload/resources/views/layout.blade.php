<!DOCTYPE html>
<html>
<head>
	<title>@yield('judul')</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('public/bootstrap/css/bootstrap.min.css')}}">
</head>
<a href="{{url('/tugas/tts')}}">TESTING</a>
<a href="{{url('/tugas/create')}}" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Tambah</a>
<body>
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<a href="{{url('/tugas/create')}}" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Tambah</a>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			@yield('konten')
		</div>
	</div>
</body>
</html>