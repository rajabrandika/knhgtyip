@extends('layout')
@section('judul')
Testing
@endsection
@section('konten')
asdasdsad
@endsection