@extends('layout')
@section('judul')
Daftar Tugas
@endsection
@section('konten')
<table class="table table-striped b-t b-light">
	<thead>
		<tr>
			<th><center>Judul</center></th>
			<th><center>Detil</center></th>
			<th><center>Edit</center></th>
			<th><center>Hapus</center></th>
		</tr>
	</thead>
	<tbody>
		@foreach($data as $a)
		<tr>
			<td><center>{{$a->judul}}</center></td>
			<td><center>
				<a href="{{ url('tugas/'.$a->id) }}" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i></a>
			</center></td>
			<td><center>
				<a href="{{ url('tugas/'.$a->id.'/edit') }}" class="btn btn-primary"><i class="glyphicon glyphicon-edit"></i></a>
			</center></td>
			<td><center>
				<form action="{{ url('tugas/'.$a->id) }}" method="post">
					<input type="hidden" name="_method" value="DELETE">
					{{ csrf_field() }}
					<input type="submit" class="btn btn-danger" value="Hapus">
				</form>
			</center></td>
		</tr>
		<!-- <a href="{{ url('tugas/daftartugas') }}" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i></a> -->
		@endforeach
	</tbody>
</table>
@endsection