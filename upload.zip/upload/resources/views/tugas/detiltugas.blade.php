@extends('layout')
@section('judul')
Detil Tugas
@endsection
@section('konten')
<h1>{{$data->id}}</h1>
<table class="table table-hover">
	<thead>
		<tr>
			<th><center>Judul</center></th>
			<th><center>Deskripsi</center></th>
			<th><center>Dibuat Pada</center></th>
		</tr>
	</thead>
	<tbody>		
		<tr>
			<td><center>{{$data->judul}}</center></td>
			<td><center>{{$data->deskripsi}}</center></td>
			<td><center>{{$data->created_at}}</center></td>
		</tr>
	</tbody>
</table>
@endsection